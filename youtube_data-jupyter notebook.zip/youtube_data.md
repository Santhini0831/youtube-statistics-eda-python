import numpy as np
import pandas as pd
import matplotlib as plt
import seaborn as sns

df=pd.read_csv("C:\project\youtube_data.csv")


```python
df

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>Youtuber</th>
      <th>subscribers</th>
      <th>video views</th>
      <th>category</th>
      <th>Title</th>
      <th>uploads</th>
      <th>Country</th>
      <th>Abbreviation</th>
      <th>channel_type</th>
      <th>...</th>
      <th>subscribers_for_last_30_days</th>
      <th>created_year</th>
      <th>created_month</th>
      <th>created_date</th>
      <th>Gross tertiary education enrollment (%)</th>
      <th>Population</th>
      <th>Unemployment rate</th>
      <th>Urban_population</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>T-Series</td>
      <td>245000000</td>
      <td>2.280000e+11</td>
      <td>Music</td>
      <td>T-Series</td>
      <td>20082</td>
      <td>India</td>
      <td>IN</td>
      <td>Music</td>
      <td>...</td>
      <td>2000000.0</td>
      <td>2006.0</td>
      <td>Mar</td>
      <td>13.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>YouTube Movies</td>
      <td>170000000</td>
      <td>0.000000e+00</td>
      <td>Film &amp; Animation</td>
      <td>youtubemovies</td>
      <td>1</td>
      <td>United States</td>
      <td>US</td>
      <td>Games</td>
      <td>...</td>
      <td>NaN</td>
      <td>2006.0</td>
      <td>Mar</td>
      <td>5.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>MrBeast</td>
      <td>166000000</td>
      <td>2.836884e+10</td>
      <td>Entertainment</td>
      <td>MrBeast</td>
      <td>741</td>
      <td>United States</td>
      <td>US</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>8000000.0</td>
      <td>2012.0</td>
      <td>Feb</td>
      <td>20.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>162000000</td>
      <td>1.640000e+11</td>
      <td>Education</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>966</td>
      <td>United States</td>
      <td>US</td>
      <td>Education</td>
      <td>...</td>
      <td>1000000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>1.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>SET India</td>
      <td>159000000</td>
      <td>1.480000e+11</td>
      <td>Shows</td>
      <td>SET India</td>
      <td>116536</td>
      <td>India</td>
      <td>IN</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>1000000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>20.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>990</th>
      <td>991</td>
      <td>Natan por Aï¿</td>
      <td>12300000</td>
      <td>9.029610e+09</td>
      <td>Sports</td>
      <td>Natan por Aï¿</td>
      <td>1200</td>
      <td>Brazil</td>
      <td>BR</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>700000.0</td>
      <td>2017.0</td>
      <td>Feb</td>
      <td>12.0</td>
      <td>51.3</td>
      <td>2.125594e+08</td>
      <td>12.08</td>
      <td>183241641.0</td>
      <td>-14.235004</td>
      <td>-51.925280</td>
    </tr>
    <tr>
      <th>991</th>
      <td>992</td>
      <td>Free Fire India Official</td>
      <td>12300000</td>
      <td>1.674410e+09</td>
      <td>People &amp; Blogs</td>
      <td>Free Fire India Official</td>
      <td>1500</td>
      <td>India</td>
      <td>IN</td>
      <td>Games</td>
      <td>...</td>
      <td>300000.0</td>
      <td>2018.0</td>
      <td>Sep</td>
      <td>14.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>992</th>
      <td>993</td>
      <td>Panda</td>
      <td>12300000</td>
      <td>2.214684e+09</td>
      <td>NaN</td>
      <td>HybridPanda</td>
      <td>2452</td>
      <td>United Kingdom</td>
      <td>GB</td>
      <td>Games</td>
      <td>...</td>
      <td>1000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>11.0</td>
      <td>60.0</td>
      <td>6.683440e+07</td>
      <td>3.85</td>
      <td>55908316.0</td>
      <td>55.378051</td>
      <td>-3.435973</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>RobTopGames</td>
      <td>12300000</td>
      <td>3.741235e+08</td>
      <td>Gaming</td>
      <td>RobTopGames</td>
      <td>39</td>
      <td>Sweden</td>
      <td>SE</td>
      <td>Games</td>
      <td>...</td>
      <td>100000.0</td>
      <td>2012.0</td>
      <td>May</td>
      <td>9.0</td>
      <td>67.0</td>
      <td>1.028545e+07</td>
      <td>6.48</td>
      <td>9021165.0</td>
      <td>60.128161</td>
      <td>18.643501</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Make Joke Of</td>
      <td>12300000</td>
      <td>2.129774e+09</td>
      <td>Comedy</td>
      <td>Make Joke Of</td>
      <td>62</td>
      <td>India</td>
      <td>IN</td>
      <td>Comedy</td>
      <td>...</td>
      <td>100000.0</td>
      <td>2017.0</td>
      <td>Aug</td>
      <td>1.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
  </tbody>
</table>
<p>995 rows × 28 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>Youtuber</th>
      <th>subscribers</th>
      <th>video views</th>
      <th>category</th>
      <th>Title</th>
      <th>uploads</th>
      <th>Country</th>
      <th>Abbreviation</th>
      <th>channel_type</th>
      <th>...</th>
      <th>subscribers_for_last_30_days</th>
      <th>created_year</th>
      <th>created_month</th>
      <th>created_date</th>
      <th>Gross tertiary education enrollment (%)</th>
      <th>Population</th>
      <th>Unemployment rate</th>
      <th>Urban_population</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>T-Series</td>
      <td>245000000</td>
      <td>2.280000e+11</td>
      <td>Music</td>
      <td>T-Series</td>
      <td>20082</td>
      <td>India</td>
      <td>IN</td>
      <td>Music</td>
      <td>...</td>
      <td>2000000.0</td>
      <td>2006.0</td>
      <td>Mar</td>
      <td>13.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>YouTube Movies</td>
      <td>170000000</td>
      <td>0.000000e+00</td>
      <td>Film &amp; Animation</td>
      <td>youtubemovies</td>
      <td>1</td>
      <td>United States</td>
      <td>US</td>
      <td>Games</td>
      <td>...</td>
      <td>NaN</td>
      <td>2006.0</td>
      <td>Mar</td>
      <td>5.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>MrBeast</td>
      <td>166000000</td>
      <td>2.836884e+10</td>
      <td>Entertainment</td>
      <td>MrBeast</td>
      <td>741</td>
      <td>United States</td>
      <td>US</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>8000000.0</td>
      <td>2012.0</td>
      <td>Feb</td>
      <td>20.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>162000000</td>
      <td>1.640000e+11</td>
      <td>Education</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>966</td>
      <td>United States</td>
      <td>US</td>
      <td>Education</td>
      <td>...</td>
      <td>1000000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>1.0</td>
      <td>88.2</td>
      <td>3.282395e+08</td>
      <td>14.70</td>
      <td>270663028.0</td>
      <td>37.090240</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>SET India</td>
      <td>159000000</td>
      <td>1.480000e+11</td>
      <td>Shows</td>
      <td>SET India</td>
      <td>116536</td>
      <td>India</td>
      <td>IN</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>1000000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>20.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>Youtuber</th>
      <th>subscribers</th>
      <th>video views</th>
      <th>category</th>
      <th>Title</th>
      <th>uploads</th>
      <th>Country</th>
      <th>Abbreviation</th>
      <th>channel_type</th>
      <th>...</th>
      <th>subscribers_for_last_30_days</th>
      <th>created_year</th>
      <th>created_month</th>
      <th>created_date</th>
      <th>Gross tertiary education enrollment (%)</th>
      <th>Population</th>
      <th>Unemployment rate</th>
      <th>Urban_population</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>990</th>
      <td>991</td>
      <td>Natan por Aï¿</td>
      <td>12300000</td>
      <td>9.029610e+09</td>
      <td>Sports</td>
      <td>Natan por Aï¿</td>
      <td>1200</td>
      <td>Brazil</td>
      <td>BR</td>
      <td>Entertainment</td>
      <td>...</td>
      <td>700000.0</td>
      <td>2017.0</td>
      <td>Feb</td>
      <td>12.0</td>
      <td>51.3</td>
      <td>2.125594e+08</td>
      <td>12.08</td>
      <td>183241641.0</td>
      <td>-14.235004</td>
      <td>-51.925280</td>
    </tr>
    <tr>
      <th>991</th>
      <td>992</td>
      <td>Free Fire India Official</td>
      <td>12300000</td>
      <td>1.674410e+09</td>
      <td>People &amp; Blogs</td>
      <td>Free Fire India Official</td>
      <td>1500</td>
      <td>India</td>
      <td>IN</td>
      <td>Games</td>
      <td>...</td>
      <td>300000.0</td>
      <td>2018.0</td>
      <td>Sep</td>
      <td>14.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>992</th>
      <td>993</td>
      <td>Panda</td>
      <td>12300000</td>
      <td>2.214684e+09</td>
      <td>NaN</td>
      <td>HybridPanda</td>
      <td>2452</td>
      <td>United Kingdom</td>
      <td>GB</td>
      <td>Games</td>
      <td>...</td>
      <td>1000.0</td>
      <td>2006.0</td>
      <td>Sep</td>
      <td>11.0</td>
      <td>60.0</td>
      <td>6.683440e+07</td>
      <td>3.85</td>
      <td>55908316.0</td>
      <td>55.378051</td>
      <td>-3.435973</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>RobTopGames</td>
      <td>12300000</td>
      <td>3.741235e+08</td>
      <td>Gaming</td>
      <td>RobTopGames</td>
      <td>39</td>
      <td>Sweden</td>
      <td>SE</td>
      <td>Games</td>
      <td>...</td>
      <td>100000.0</td>
      <td>2012.0</td>
      <td>May</td>
      <td>9.0</td>
      <td>67.0</td>
      <td>1.028545e+07</td>
      <td>6.48</td>
      <td>9021165.0</td>
      <td>60.128161</td>
      <td>18.643501</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Make Joke Of</td>
      <td>12300000</td>
      <td>2.129774e+09</td>
      <td>Comedy</td>
      <td>Make Joke Of</td>
      <td>62</td>
      <td>India</td>
      <td>IN</td>
      <td>Comedy</td>
      <td>...</td>
      <td>100000.0</td>
      <td>2017.0</td>
      <td>Aug</td>
      <td>1.0</td>
      <td>28.1</td>
      <td>1.366418e+09</td>
      <td>5.36</td>
      <td>471031528.0</td>
      <td>20.593684</td>
      <td>78.962880</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 995 entries, 0 to 994
    Data columns (total 28 columns):
     #   Column                                   Non-Null Count  Dtype  
    ---  ------                                   --------------  -----  
     0   rank                                     995 non-null    int64  
     1   Youtuber                                 995 non-null    object 
     2   subscribers                              995 non-null    int64  
     3   video views                              995 non-null    float64
     4   category                                 949 non-null    object 
     5   Title                                    995 non-null    object 
     6   uploads                                  995 non-null    int64  
     7   Country                                  873 non-null    object 
     8   Abbreviation                             873 non-null    object 
     9   channel_type                             965 non-null    object 
     10  video_views_rank                         994 non-null    float64
     11  country_rank                             879 non-null    float64
     12  channel_type_rank                        962 non-null    float64
     13  video_views_for_the_last_30_days         939 non-null    float64
     14  lowest_monthly_earnings                  995 non-null    float64
     15  highest_monthly_earnings                 995 non-null    float64
     16  lowest_yearly_earnings                   995 non-null    float64
     17  highest_yearly_earnings                  995 non-null    float64
     18  subscribers_for_last_30_days             658 non-null    float64
     19  created_year                             990 non-null    float64
     20  created_month                            990 non-null    object 
     21  created_date                             990 non-null    float64
     22  Gross tertiary education enrollment (%)  872 non-null    float64
     23  Population                               872 non-null    float64
     24  Unemployment rate                        872 non-null    float64
     25  Urban_population                         872 non-null    float64
     26  Latitude                                 872 non-null    float64
     27  Longitude                                872 non-null    float64
    dtypes: float64(18), int64(3), object(7)
    memory usage: 217.8+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>subscribers</th>
      <th>video views</th>
      <th>uploads</th>
      <th>video_views_rank</th>
      <th>country_rank</th>
      <th>channel_type_rank</th>
      <th>video_views_for_the_last_30_days</th>
      <th>lowest_monthly_earnings</th>
      <th>highest_monthly_earnings</th>
      <th>...</th>
      <th>highest_yearly_earnings</th>
      <th>subscribers_for_last_30_days</th>
      <th>created_year</th>
      <th>created_date</th>
      <th>Gross tertiary education enrollment (%)</th>
      <th>Population</th>
      <th>Unemployment rate</th>
      <th>Urban_population</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>995.00000</td>
      <td>9.950000e+02</td>
      <td>9.950000e+02</td>
      <td>995.000000</td>
      <td>9.940000e+02</td>
      <td>879.000000</td>
      <td>962.000000</td>
      <td>9.390000e+02</td>
      <td>995.000000</td>
      <td>9.950000e+02</td>
      <td>...</td>
      <td>9.950000e+02</td>
      <td>6.580000e+02</td>
      <td>990.000000</td>
      <td>990.000000</td>
      <td>872.000000</td>
      <td>8.720000e+02</td>
      <td>872.000000</td>
      <td>8.720000e+02</td>
      <td>872.000000</td>
      <td>872.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>498.00000</td>
      <td>2.298241e+07</td>
      <td>1.103954e+10</td>
      <td>9187.125628</td>
      <td>5.542489e+05</td>
      <td>386.053470</td>
      <td>745.719335</td>
      <td>1.756103e+08</td>
      <td>36886.148281</td>
      <td>5.898078e+05</td>
      <td>...</td>
      <td>7.081814e+06</td>
      <td>3.490791e+05</td>
      <td>2012.630303</td>
      <td>15.746465</td>
      <td>63.627752</td>
      <td>4.303873e+08</td>
      <td>9.279278</td>
      <td>2.242150e+08</td>
      <td>26.632783</td>
      <td>-14.128146</td>
    </tr>
    <tr>
      <th>std</th>
      <td>287.37606</td>
      <td>1.752611e+07</td>
      <td>1.411084e+10</td>
      <td>34151.352254</td>
      <td>1.362782e+06</td>
      <td>1232.244746</td>
      <td>1944.386561</td>
      <td>4.163782e+08</td>
      <td>71858.724092</td>
      <td>1.148622e+06</td>
      <td>...</td>
      <td>1.379704e+07</td>
      <td>6.143554e+05</td>
      <td>4.512503</td>
      <td>8.777520</td>
      <td>26.106893</td>
      <td>4.727947e+08</td>
      <td>4.888354</td>
      <td>1.546874e+08</td>
      <td>20.560533</td>
      <td>84.760809</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.00000</td>
      <td>1.230000e+07</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>1.000000e+00</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>1.000000e+00</td>
      <td>1970.000000</td>
      <td>1.000000</td>
      <td>7.600000</td>
      <td>2.025060e+05</td>
      <td>0.750000</td>
      <td>3.558800e+04</td>
      <td>-38.416097</td>
      <td>-172.104629</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>249.50000</td>
      <td>1.450000e+07</td>
      <td>4.288145e+09</td>
      <td>194.500000</td>
      <td>3.230000e+02</td>
      <td>11.000000</td>
      <td>27.000000</td>
      <td>2.013750e+07</td>
      <td>2700.000000</td>
      <td>4.350000e+04</td>
      <td>...</td>
      <td>5.217500e+05</td>
      <td>1.000000e+05</td>
      <td>2009.000000</td>
      <td>8.000000</td>
      <td>36.300000</td>
      <td>8.335541e+07</td>
      <td>5.270000</td>
      <td>5.590832e+07</td>
      <td>20.593684</td>
      <td>-95.712891</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>498.00000</td>
      <td>1.770000e+07</td>
      <td>7.760820e+09</td>
      <td>729.000000</td>
      <td>9.155000e+02</td>
      <td>51.000000</td>
      <td>65.500000</td>
      <td>6.408500e+07</td>
      <td>13300.000000</td>
      <td>2.127000e+05</td>
      <td>...</td>
      <td>2.600000e+06</td>
      <td>2.000000e+05</td>
      <td>2013.000000</td>
      <td>16.000000</td>
      <td>68.000000</td>
      <td>3.282395e+08</td>
      <td>9.365000</td>
      <td>2.706630e+08</td>
      <td>37.090240</td>
      <td>-51.925280</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>746.50000</td>
      <td>2.460000e+07</td>
      <td>1.355470e+10</td>
      <td>2667.500000</td>
      <td>3.584500e+03</td>
      <td>123.000000</td>
      <td>139.750000</td>
      <td>1.688265e+08</td>
      <td>37900.000000</td>
      <td>6.068000e+05</td>
      <td>...</td>
      <td>7.300000e+06</td>
      <td>4.000000e+05</td>
      <td>2016.000000</td>
      <td>23.000000</td>
      <td>88.200000</td>
      <td>3.282395e+08</td>
      <td>14.700000</td>
      <td>2.706630e+08</td>
      <td>37.090240</td>
      <td>78.962880</td>
    </tr>
    <tr>
      <th>max</th>
      <td>995.00000</td>
      <td>2.450000e+08</td>
      <td>2.280000e+11</td>
      <td>301308.000000</td>
      <td>4.057944e+06</td>
      <td>7741.000000</td>
      <td>7741.000000</td>
      <td>6.589000e+09</td>
      <td>850900.000000</td>
      <td>1.360000e+07</td>
      <td>...</td>
      <td>1.634000e+08</td>
      <td>8.000000e+06</td>
      <td>2022.000000</td>
      <td>31.000000</td>
      <td>113.100000</td>
      <td>1.397715e+09</td>
      <td>14.720000</td>
      <td>8.429340e+08</td>
      <td>61.924110</td>
      <td>138.252924</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 21 columns</p>
</div>




```python
df.isna().sum()
```




    rank                                         0
    Youtuber                                     0
    subscribers                                  0
    video views                                  0
    category                                    46
    Title                                        0
    uploads                                      0
    Country                                    122
    Abbreviation                               122
    channel_type                                30
    video_views_rank                             1
    country_rank                               116
    channel_type_rank                           33
    video_views_for_the_last_30_days            56
    lowest_monthly_earnings                      0
    highest_monthly_earnings                     0
    lowest_yearly_earnings                       0
    highest_yearly_earnings                      0
    subscribers_for_last_30_days               337
    created_year                                 5
    created_month                                5
    created_date                                 5
    Gross tertiary education enrollment (%)    123
    Population                                 123
    Unemployment rate                          123
    Urban_population                           123
    Latitude                                   123
    Longitude                                  123
    dtype: int64




```python
df.duplicated().sum()
```




    np.int64(0)




```python
df.columns
```




    Index(['rank', 'Youtuber', 'subscribers', 'video views', 'category', 'Title',
           'uploads', 'Country', 'Abbreviation', 'channel_type',
           'video_views_rank', 'country_rank', 'channel_type_rank',
           'video_views_for_the_last_30_days', 'lowest_monthly_earnings',
           'highest_monthly_earnings', 'lowest_yearly_earnings',
           'highest_yearly_earnings', 'subscribers_for_last_30_days',
           'created_year', 'created_month', 'created_date',
           'Gross tertiary education enrollment (%)', 'Population',
           'Unemployment rate', 'Urban_population', 'Latitude', 'Longitude'],
          dtype='object')




```python
category_subscribers_mean = df.groupby("category")["subscribers"].mean()
category_subscribers_mean
```




    category
    Autos & Vehicles         1.785000e+07
    Comedy                   2.012319e+07
    Education                2.654222e+07
    Entertainment            2.140332e+07
    Film & Animation         2.858478e+07
    Gaming                   2.085213e+07
    Howto & Style            1.939000e+07
    Movies                   2.565000e+07
    Music                    2.571782e+07
    News & Politics          2.063077e+07
    Nonprofits & Activism    2.775000e+07
    People & Blogs           2.105606e+07
    Pets & Animals           1.810000e+07
    Science & Technology     1.861765e+07
    Shows                    4.161538e+07
    Sports                   2.710909e+07
    Trailers                 3.900000e+07
    Travel & Events          1.250000e+07
    Name: subscribers, dtype: float64




```python
pd.set_option("display.float_format","{:.2f}".format)
```


```python
category_subscribers_mean = df.groupby("category")["subscribers"].mean()
category_subscribers_mean
```




    category
    Autos & Vehicles        17850000.00
    Comedy                  20123188.41
    Education               26542222.22
    Entertainment           21403319.50
    Film & Animation        28584782.61
    Gaming                  20852127.66
    Howto & Style           19390000.00
    Movies                  25650000.00
    Music                   25717821.78
    News & Politics         20630769.23
    Nonprofits & Activism   27750000.00
    People & Blogs          21056060.61
    Pets & Animals          18100000.00
    Science & Technology    18617647.06
    Shows                   41615384.62
    Sports                  27109090.91
    Trailers                39000000.00
    Travel & Events         12500000.00
    Name: subscribers, dtype: float64




```python
category_subscribers_mean.sort_values(ascending=False,inplace=True)
```


```python
category_subscribers_mean.plot(kind="bar")
plt.title("mean subscribers by category")
plt.xlabel("category")
plt.ylabel("subscribers")
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[35], line 2
          1 category_subscribers_mean.plot(kind="bar")
    ----> 2 plt.title("mean subscribers by category")
          3 plt.xlabel("category")
          4 plt.ylabel("subscribers")
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'title'



    
![png](output_14_1.png)
    



```python
category_subscribers_mean.head(7).plot(kind="bar")
plt.title("mean subscribers by category")
plt.xlabel("category")
plt.ylabel("subscribers")
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[43], line 2
          1 category_subscribers_mean.head(7).plot(kind="bar")
    ----> 2 plt.title("mean subscribers by category")
          3 plt.xlabel("category")
          4 plt.ylabel("subscribers")
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'title'



    
![png](output_15_1.png)
    



```python
channel_type_counts = df["channel_type"].value_counts()
channel_type_counts
```




    channel_type
    Entertainment    304
    Music            216
    People           101
    Games             98
    Comedy            51
    Education         49
    Film              42
    Howto             36
    News              30
    Tech              17
    Sports            13
    Autos              3
    Animals            3
    Nonprofit          2
    Name: count, dtype: int64




```python
channel_type_counts.head().plot(kind="pie")
plt.title("channel type distribution")
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[41], line 2
          1 channel_type_counts.head().plot(kind="pie")
    ----> 2 plt.title("channel type distribution")
          3 plt.show()
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'title'



    
![png](output_17_1.png)
    



```python
country_subscribers_total = df.groupby("Country")["subscribers"].sum().sort_values(ascending=False)
country_subscribers_total
```




    Country
    United States           7329500000
    India                   4310600000
    Brazil                  1221800000
    United Kingdom           917400000
    Mexico                   626900000
    Indonesia                534100000
    South Korea              481700000
    Russia                   407200000
    Thailand                 386500000
    Spain                    385100000
    Canada                   363900000
    Argentina                328500000
    Colombia                 264500000
    Philippines              240100000
    Japan                    189100000
    Saudi Arabia             179100000
    Australia                172000000
    Pakistan                 155400000
    United Arab Emirates     148200000
    Ukraine                  125600000
    Germany                  116400000
    Turkey                    91600000
    Chile                     87200000
    France                    83900000
    Jordan                    67000000
    Sweden                    63000000
    Singapore                 59700000
    Netherlands               58100000
    Vietnam                   47800000
    Cuba                      46300000
    El Salvador               46100000
    Barbados                  41900000
    Italy                     39400000
    Venezuela                 31200000
    Egypt                     30600000
    Kuwait                    30500000
    Iraq                      30200000
    Ecuador                   27700000
    Afghanistan               20400000
    Latvia                    20200000
    Switzerland               19400000
    Malaysia                  17700000
    China                     17600000
    Andorra                   15100000
    Morocco                   14500000
    Peru                      14400000
    Bangladesh                13900000
    Finland                   13200000
    Samoa                     13100000
    Name: subscribers, dtype: int64




```python
country_subscribers_total.head(10).plot(kind="bar")
plt.xlabel("Country")
plt.ylabel("total subscribers")
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[49], line 2
          1 country_subscribers_total.head(10).plot(kind="bar")
    ----> 2 plt.xlabel("Country")
          3 plt.ylabel("total subscribers")
          4 plt.show()
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'xlabel'



    
![png](output_19_1.png)
    



```python
df.groupby("created_year")["subscribers"].mean().sort_values(ascending=True)
```




    created_year
    2022.00   13640000.00
    2021.00   18573913.04
    2019.00   18639393.94
    2017.00   18666176.47
    2014.00   20618367.35
    2010.00   20670833.33
    2015.00   21247945.21
    2020.00   21350000.00
    2011.00   21800000.00
    2018.00   23060869.57
    2016.00   23101298.70
    2009.00   23105769.23
    2008.00   23652173.91
    2012.00   24038235.29
    2013.00   24527631.58
    2007.00   24902040.82
    2005.00   25829166.67
    2006.00   31884615.38
    1970.00   36300000.00
    Name: subscribers, dtype: float64




```python
pd.set_option("display.float_format","{:.0f}".format)
```


```python
df.groupby("created_year")["subscribers"].mean().sort_values(ascending=True)
```




    created_year
    2022   13640000
    2021   18573913
    2019   18639394
    2017   18666176
    2014   20618367
    2010   20670833
    2015   21247945
    2020   21350000
    2011   21800000
    2018   23060870
    2016   23101299
    2009   23105769
    2008   23652174
    2012   24038235
    2013   24527632
    2007   24902041
    2005   25829167
    2006   31884615
    1970   36300000
    Name: subscribers, dtype: float64




```python
df.groupby("channel_type")["video_views_rank"].median().sort_values(ascending=False)
```




    channel_type
    Autos           3468229
    Tech               2420
    Games              1944
    People             1868
    Howto              1574
    Nonprofit          1538
    Sports             1186
    Comedy             1033
    Film                880
    Entertainment       796
    News                612
    Education           538
    Music               385
    Animals             136
    Name: video_views_rank, dtype: float64




```python
df.groupby("Country")["subscribers_for_last_30_days"].max().sort_values(ascending=False)
```




    Country
    United States           8000000.0
    Indonesia               5500000.0
    United Arab Emirates    3400000.0
    South Korea             3200000.0
    Sweden                  3000000.0
    Turkey                  2100000.0
    Italy                   2000000.0
    India                   2000000.0
    Argentina               1900000.0
    Colombia                1600000.0
    Russia                  1600000.0
    Pakistan                1300000.0
    Kuwait                  1300000.0
    Latvia                  1200000.0
    Brazil                  1100000.0
    Japan                   1100000.0
    Germany                  900000.0
    Spain                    800000.0
    Australia                600000.0
    United Kingdom           600000.0
    Mexico                   600000.0
    Philippines              500000.0
    Saudi Arabia             500000.0
    Chile                    500000.0
    Canada                   400000.0
    Ecuador                  300000.0
    Thailand                 300000.0
    Jordan                   300000.0
    Ukraine                  230000.0
    Netherlands              200000.0
    Malaysia                 200000.0
    Vietnam                  200000.0
    Singapore                200000.0
    El Salvador              200000.0
    China                    100000.0
    France                   100000.0
    Switzerland              100000.0
    Barbados                 100000.0
    Egypt                    100000.0
    Venezuela                   100.0
    Afghanistan                  12.0
    Cuba                         10.0
    Samoa                         3.0
    Andorra                       NaN
    Bangladesh                    NaN
    Finland                       NaN
    Iraq                          NaN
    Morocco                       NaN
    Peru                          NaN
    Name: subscribers_for_last_30_days, dtype: float64




```python
df.groupby("created_month")["subscribers"].sum()

```




    created_month
    Apr    1581200000
    Aug    1813600000
    Dec    1577300000
    Feb    1533800000
    Jan    2254600000
    Jul    1922300000
    Jun    1846400000
    Mar    2320500000
    May    1997700000
    Nov    1930200000
    Oct    1503700000
    Sep    2496200000
    Name: subscribers, dtype: int64




```python
df.groupby("category")["video views"].std()
```




    category
    Autos & Vehicles         2964425983.84
    Comedy                   6406251669.42
    Education               25572139026.30
    Entertainment           10128204611.48
    Film & Animation        10899550880.91
    Gaming                   5835933598.17
    Howto & Style            4300326961.46
    Movies                   3353301875.46
    Music                   17782784424.31
    News & Politics          5165961804.90
    Nonprofits & Activism    2698145850.47
    People & Blogs          12510420847.25
    Pets & Animals           6475165093.46
    Science & Technology     2937981619.12
    Shows                   43723894661.85
    Sports                  21703831459.30
    Trailers                 1382496086.18
    Travel & Events                    NaN
    Name: video views, dtype: float64




```python
df.groupby("Country")["Unemployment rate"].min().sort_values(ascending=True)
```




    Country
    Thailand                0.75
    Cuba                    1.64
    Vietnam                 2.01
    Philippines             2.15
    Kuwait                  2.18
    Japan                   2.29
    United Arab Emirates    2.35
    Germany                 3.04
    Netherlands             3.20
    Peru                    3.31
    Malaysia                3.32
    Mexico                  3.42
    United Kingdom          3.85
    Ecuador                 3.97
    El Salvador             4.11
    Singapore               4.11
    South Korea             4.15
    Bangladesh              4.19
    China                   4.32
    Pakistan                4.45
    Switzerland             4.58
    Russia                  4.59
    Indonesia               4.69
    Australia               5.27
    India                   5.36
    Canada                  5.56
    Saudi Arabia            5.93
    Sweden                  6.48
    Latvia                  6.52
    Finland                 6.59
    Chile                   7.09
    Samoa                   8.36
    France                  8.43
    Venezuela               8.80
    Ukraine                 8.88
    Morocco                 9.02
    Colombia                9.71
    Argentina               9.79
    Italy                   9.89
    Barbados               10.33
    Egypt                  10.76
    Afghanistan            11.12
    Brazil                 12.08
    Iraq                   12.82
    Turkey                 13.49
    Spain                  13.96
    United States          14.70
    Jordan                 14.72
    Andorra                  NaN
    Name: Unemployment rate, dtype: float64




```python
df.groupby("channel_type")["uploads"].sum()
```




    channel_type
    Animals            42868
    Autos                949
    Comedy             81722
    Education         146355
    Entertainment    3345035
    Film              114654
    Games             399473
    Howto              79417
    Music             424950
    News             3989151
    Nonprofit         205824
    People            117424
    Sports            158995
    Tech               33780
    Name: uploads, dtype: int64




```python
df.groupby(["Latitude","Longitude"]).size()
```




    Latitude  Longitude
    -38.42    -63.62        13
    -35.68    -71.54         3
    -25.27    133.78         9
    -14.24    -51.93        62
    -13.76    -172.10        1
    -9.19     -75.02         1
    -1.83     -78.18         2
    -0.79     113.92        28
    1.35      103.82         3
    4.21      101.98         1
    4.57      -74.30        11
    6.42      -66.59         1
    12.88     121.77        12
    13.19     -59.54         1
    13.79     -88.90         1
    14.06     108.28         3
    15.87     100.99        18
    20.59     78.96        168
    21.52     -77.78         1
    23.42     53.85          7
    23.63     -102.55       33
    23.68     90.36          1
    23.89     45.08          9
    26.82     30.80          2
    29.31     47.48          1
    30.38     69.35          6
    30.59     36.24          3
    31.79     -7.09          1
    33.22     43.68          2
    33.94     67.71          1
    35.86     104.20         1
    35.91     127.77        17
    36.20     138.25         5
    37.09     -95.71       313
    38.96     35.24          4
    40.46     -3.75         22
    41.87     12.57          2
    46.23     2.21           5
    46.82     8.23           1
    48.38     31.17          8
    51.17     10.45          6
    52.13     5.29           3
    55.38     -3.44         43
    56.13     -106.35       15
    56.88     24.60          1
    60.13     18.64          4
    61.52     105.32        16
    61.92     25.75          1
    dtype: int64




```python
sns.boxplot(x="channel_type",y="highest_monthly_earnings",data=df)
plt.title("distribution of highest monthly earning by channel type")
plt.xticks(rotation=90)
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[20], line 2
          1 sns.boxplot(x="channel_type",y="highest_monthly_earnings",data=df)
    ----> 2 plt.title("distribution of highest monthly earning by channel type")
          3 plt.xticks(rotation=90)
          4 plt.show()
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'title'



    
![png](output_31_1.png)
    



```python
df.groupby(["category","Country"])["subscribers"].sum().unstack().plot(kind="bar",stacked=True)
plt.xlabel("category")
plt.ylabel("total subscribers")
plt.legend(title="Country",bbox_to_anchor=(1.05,1),loc="upper left")
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[24], line 2
          1 df.groupby(["category","Country"])["subscribers"].sum().unstack().plot(kind="bar",stacked=True)
    ----> 2 plt.xlabel("category")
          3 plt.ylabel("total subscribers")
          4 plt.legend(title="Country",bbox_to_anchor=(1.05,1),loc="upper left")
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'xlabel'



    
![png](output_32_1.png)
    



```python
plt.scatter(df["Gross tertiary education enrollment(%)"],df["subscribers"],alpha=0.9)
plt.title("scatter plot of subscribers vs gross tertiary education enrollment")
plt.xlabel("gross tertiary education enrollment")
plt.ylabel("subscribers")

```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[28], line 1
    ----> 1 plt.scatter(df["Gross tertiary education enrollment(%)"],df["subscribers"],alpha=0.9)
          2 plt.title("scatter plot of subscribers vs gross tertiary education enrollment")
          3 plt.xlabel("gross tertiary education enrollment")
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'scatter'



```python
df.groupby("channel_type")["Unemployment rate"].mean().plot(kind="bar")
plt.title("average unemployment rate by channel type")
plt.xlabel("channel_type")
plt.ylabel("average Unemployment rate")
plt.show()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[30], line 2
          1 df.groupby("channel_type")["Unemployment rate"].mean().plot(kind="bar")
    ----> 2 plt.title("average unemployment rate by channel type")
          3 plt.xlabel("channel_type")
          4 plt.ylabel("average Unemployment rate")
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\matplotlib\_api\__init__.py:218, in caching_module_getattr.<locals>.__getattr__(name)
        216 if name in props:
        217     return props[name].__get__(instance)
    --> 218 raise AttributeError(
        219     f"module {cls.__module__!r} has no attribute {name!r}")
    

    AttributeError: module 'matplotlib' has no attribute 'title'



    
![png](output_34_1.png)
    



```python
channel_created_subscribers_mean=df.groupby(["channel_type","created_year"])["subscribers_for_last_30_days"].mean().unstack()
channel_created_subscribers_mean
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>created_year</th>
      <th>1970.00</th>
      <th>2005.00</th>
      <th>2006.00</th>
      <th>2007.00</th>
      <th>2008.00</th>
      <th>2009.00</th>
      <th>2010.00</th>
      <th>2011.00</th>
      <th>2012.00</th>
      <th>2013.00</th>
      <th>2014.00</th>
      <th>2015.00</th>
      <th>2016.00</th>
      <th>2017.00</th>
      <th>2018.00</th>
      <th>2019.00</th>
      <th>2020.00</th>
      <th>2021.00</th>
      <th>2022.00</th>
    </tr>
    <tr>
      <th>channel_type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Animals</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>600000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Autos</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.00</td>
      <td>500000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Comedy</th>
      <td>NaN</td>
      <td>400000.00</td>
      <td>100000.00</td>
      <td>100000.25</td>
      <td>200000.00</td>
      <td>400000.00</td>
      <td>NaN</td>
      <td>50000.50</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>1166666.67</td>
      <td>150000.00</td>
      <td>700000.00</td>
      <td>100000.00</td>
      <td>200050.00</td>
      <td>1000000.00</td>
      <td>1200000.00</td>
      <td>600000.00</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Education</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>700000.00</td>
      <td>NaN</td>
      <td>200000.00</td>
      <td>100000.00</td>
      <td>200000.00</td>
      <td>200000.00</td>
      <td>350000.00</td>
      <td>283333.33</td>
      <td>550000.00</td>
      <td>200000.00</td>
      <td>233333.33</td>
      <td>200000.00</td>
      <td>200000.00</td>
      <td>100000.00</td>
      <td>300000.00</td>
      <td>NaN</td>
      <td>300000.00</td>
    </tr>
    <tr>
      <th>Entertainment</th>
      <td>300000.00</td>
      <td>325000.00</td>
      <td>306250.50</td>
      <td>342857.29</td>
      <td>450000.00</td>
      <td>480000.00</td>
      <td>212575.00</td>
      <td>442857.14</td>
      <td>760000.00</td>
      <td>233334.00</td>
      <td>200000.00</td>
      <td>300000.00</td>
      <td>830001.40</td>
      <td>700000.00</td>
      <td>230769.23</td>
      <td>160000.00</td>
      <td>1212500.00</td>
      <td>580000.00</td>
      <td>500000.00</td>
    </tr>
    <tr>
      <th>Film</th>
      <td>NaN</td>
      <td>1.00</td>
      <td>333333.33</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>225007.50</td>
      <td>300000.00</td>
      <td>350000.00</td>
      <td>342857.14</td>
      <td>250000.00</td>
      <td>250000.00</td>
      <td>600000.00</td>
      <td>NaN</td>
      <td>500000.00</td>
      <td>450500.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Games</th>
      <td>NaN</td>
      <td>100000.00</td>
      <td>337.67</td>
      <td>50005.50</td>
      <td>100000.00</td>
      <td>200000.00</td>
      <td>3.00</td>
      <td>150000.00</td>
      <td>376923.15</td>
      <td>245454.55</td>
      <td>260000.00</td>
      <td>660716.00</td>
      <td>357142.86</td>
      <td>100003.33</td>
      <td>151000.00</td>
      <td>NaN</td>
      <td>750000.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Howto</th>
      <td>NaN</td>
      <td>500000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>100000.00</td>
      <td>100000.00</td>
      <td>633333.33</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>300000.00</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Music</th>
      <td>NaN</td>
      <td>160000.20</td>
      <td>433333.67</td>
      <td>146159.62</td>
      <td>185384.85</td>
      <td>153846.15</td>
      <td>175000.00</td>
      <td>158829.41</td>
      <td>200000.00</td>
      <td>400000.00</td>
      <td>230769.23</td>
      <td>125016.25</td>
      <td>240010.00</td>
      <td>300000.00</td>
      <td>300000.00</td>
      <td>50005.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>News</th>
      <td>NaN</td>
      <td>100000.00</td>
      <td>205000.00</td>
      <td>440000.00</td>
      <td>100000.00</td>
      <td>275000.00</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>400000.00</td>
      <td>100000.00</td>
      <td>200000.00</td>
      <td>300000.00</td>
      <td>300000.00</td>
      <td>100000.00</td>
      <td>700000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Nonprofit</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>400000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>People</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.50</td>
      <td>NaN</td>
      <td>350000.00</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>300000.00</td>
      <td>200000.00</td>
      <td>300000.00</td>
      <td>512500.00</td>
      <td>550000.33</td>
      <td>322233.78</td>
      <td>683333.33</td>
      <td>575000.00</td>
      <td>400200.00</td>
      <td>1040200.00</td>
      <td>637871.12</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>Sports</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.25</td>
      <td>600000.00</td>
      <td>NaN</td>
      <td>350000.00</td>
      <td>100000.00</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3000000.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Tech</th>
      <td>NaN</td>
      <td>100000.00</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>1100000.00</td>
      <td>233333.33</td>
      <td>500000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100000.00</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.heatmap(channel_created_subscribers_mean.head(),cmap="cool")
```




    <Axes: xlabel='created_year', ylabel='channel_type'>




    
![png](output_36_1.png)
    



```python
df.groupby("created_month")["subscribers_for_last_30_days"].mean().plot(kind="line",marker="o")
```




    <Axes: xlabel='created_month'>




    
![png](output_38_1.png)
    



```python

```
